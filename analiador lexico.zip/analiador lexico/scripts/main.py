from analizador_lexico import AnalizadorLexico
from parser_norselang import AnalizadorSintactico

codigo = '''
ritual saludo(nombre):
    drakkar "Hola, " + nombre
'''

lexico = AnalizadorLexico()
tokens = lexico.analizar(codigo)

print("Tokens generados:")
for token in tokens:
    print(token)

# Análisis sintáctico con AST
sintactico = AnalizadorSintactico(tokens)
ast = sintactico.analizar()

print("\nAST generado:")
from pprint import pprint
pprint(ast)
