Materia: Programacion de Sistemas Base 1

Institucion: Universidad Autonoma de Tamaulipas

Semestre: Octavo semester de 2025

Profesor: Dante Adolfo Muños Quintero

Integrantes;

Cristhian Michel Sandoval Vazquez

Efrain Alejandro Ortiz Doria