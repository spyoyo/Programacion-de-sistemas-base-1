import re

class AnalizadorLexico:
    def __init__(self):

        self.reglas = {
            'PALABRA_RESERVADA': r'\b(odin|thor|loki|mjolnir|valhalla|yggdrasil|si|sino|Hela|ragnarok|ritual|drakkar|runa)\b',
            'TIPO_DATO': r'\b(odin|thor|loki|mjolnir|valhalla)\b',
            'OPERADOR': r'==|\.=>|<=|\+|\-|\*|\/',
            'IDENTIFICADOR': r'[a-zA-Z_][a-zA-Z0-9_]*',
            'NUMERO': r'\b\d+(\.\d+)?\b',
            'CADENA': r'\".*?\"',
            'DELIMITADOR': r'[,\;\{\}\(\):]',
            'SALTO_DE_LINEA': r'\r?\n',
            'ESPACIOS': r'[ \t]+',
            'DESCONOCIDO': r'.'
        }

    def analizar(self, codigo):
        tokens = []
        while codigo:
            for tipo, patron in self.reglas.items():
                regex = re.match(patron, codigo)
                if regex:
                    valor = regex.group(0)
                    if tipo != 'ESPACIOS':
                        tokens.append((tipo, valor))
                    codigo = codigo[len(valor):]
                    break
        return tokens