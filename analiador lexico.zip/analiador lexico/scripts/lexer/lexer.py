class AnalizadorLexico:
    def __init__(self):
        self.tokens = []
        self.posicion = 0
        self.codigo = ""

    def reiniciar(self, codigo):
        """Reinicia el analizador léxico con un nuevo código."""
        self.codigo = codigo
        self.posicion = 0
        self.tokens = []

    def obtener_caracter(self):
        """Obtiene el siguiente carácter del código."""
        if self.posicion < len(self.codigo):
            return self.codigo[self.posicion]
        return None

    def avanzar(self):
        """Avanza al siguiente carácter."""
        self.posicion += 1

    def analizar_identificador(self):
        """Analiza un identificador (letras o números, comenzando con letra)."""
        inicio = self.posicion
        while self.obtener_caracter() and (self.obtener_caracter().isalnum() or self.obtener_caracter() == '_'):
            self.avanzar()
        return self.codigo[inicio:self.posicion]

    def analizar_numero(self):
        """Analiza un número (entero o decimal)."""
        inicio = self.posicion
        while self.obtener_caracter() and self.obtener_caracter().isdigit():
            self.avanzar()
        if self.obtener_caracter() == '.':
            self.avanzar()
            while self.obtener_caracter() and self.obtener_caracter().isdigit():
                self.avanzar()
        return self.codigo[inicio:self.posicion]

    def analizar_palabra_reservada(self):
        """Analiza una palabra reservada."""
        palabras_reservadas = ['odin', 'thor', 'loki', 'mjolnir', 'valhalla', 'yggdrasil', 'si', 'sino', 'Hela', 'ragnarok', 'ritual', 'drakkar', 'runa']
        palabra = self.analizar_identificador()
        if palabra in palabras_reservadas:
            return palabra
        return None

    def analizar(self, codigo):
        """Método principal de análisis léxico utilizando autómatas finitos."""
        self.reiniciar(codigo)
        while self.obtener_caracter():
            caracter = self.obtener_caracter()

            if caracter in ' \t\r\n':
                self.avanzar()
                continue

            if caracter.isalpha() or caracter == '_':
                palabra = self.analizar_identificador()
                palabra_reservada = self.analizar_palabra_reservada()
                if palabra_reservada:
                    self.tokens.append(('PALABRA_RESERVADA', palabra_reservada))
                else:
                    self.tokens.append(('IDENTIFICADOR', palabra))
                continue

            if caracter.isdigit():
                numero = self.analizar_numero()
                self.tokens.append(('NUMERO', numero))
                continue

            if caracter == '=':
                self.tokens.append(('OPERADOR', '='))  # Ejemplo de operador
                self.avanzar()
                continue

            if caracter == '+':
                self.tokens.append(('OPERADOR', '+'))
                self.avanzar()
                continue

            if caracter == ',':
                self.tokens.append(('DELIMITADOR', ','))
                self.avanzar()
                continue

            if caracter == ':':
                self.tokens.append(('DELIMITADOR', ':'))
                self.avanzar()
                continue

            self.tokens.append(('ERROR_LEXICO', f'Carácter no reconocido: {caracter}'))
            self.avanzar()

        return self.tokens

codigo = """
runa x = 5 @ 3;   # El símbolo '@' es inválido

invocar "Hechizo incompleto;

runa energía = 3.1e+5g;  # La 'g' no debería estar
"""




analizador = AnalizadorLexico()
tokens = analizador.analizar(codigo)

for tipo, valor in tokens:
    print(f"({tipo}, '{valor}')")
