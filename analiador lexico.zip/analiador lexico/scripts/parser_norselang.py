class SintacticoError(Exception):
    pass
class AnalizadorSintactico:
    def __init__(self, tokens):
        self.tokens = tokens
        self.indice = 0
        self.ast = []
    def obtener_token_actual(self):
        if self.indice < len(self.tokens):
            return self.tokens[self.indice]
        return None
    def siguiente_token(self):
        self.indice += 1
    def es_token(self, tipo, valor=None):
        token = self.obtener_token_actual()
        if not token:
            return False
        if valor:
            return token[0] == tipo and token[1] == valor
        return token[0] == tipo
    def ignorar_saltos(self):
        while self.es_token('SALTO_DE_LINEA'):
            self.siguiente_token()
    def parametros(self):
        params = []
        while self.es_token('IDENTIFICADOR'):
            params.append(self.obtener_token_actual()[1])
            self.siguiente_token()
            if self.es_token('DELIMITADOR', ','):
                self.siguiente_token()
            else:
                break
        return params
    def instrucciones(self):
        self.ignorar_saltos()
        instrucciones = []
        while self.obtener_token_actual() is not None:
            if self.es_token('PALABRA_RESERVADA', 'drakkar'):
                self.siguiente_token()
                if self.es_token('CADENA'):
                    cadena = self.obtener_token_actual()[1]
                    self.siguiente_token()
                    if self.es_token('OPERADOR', '+'):
                        self.siguiente_token()
                        if self.es_token('IDENTIFICADOR'):
                            variable = self.obtener_token_actual()[1]
                            self.siguiente_token()
                            instrucciones.append({
                                'tipo': 'drakkar',
                                'valor': {
                                    'cadena': cadena,
                                    'concatenar': variable
                                }
                            })
                        else:
                            raise SintacticoError("Se esperaba un identificador después de '+'.")
                    else:
                        instrucciones.append({
                            'tipo': 'drakkar',
                            'valor': cadena
                        })
                else:
                    raise SintacticoError("Se esperaba una cadena después de 'drakkar'.")
            else:
                break
            self.ignorar_saltos()
        return instrucciones
    def declaracion_funcion(self):
        self.ignorar_saltos()
        if self.es_token('PALABRA_RESERVADA', 'ritual'):
            self.siguiente_token()
            if self.es_token('IDENTIFICADOR'):
                nombre = self.obtener_token_actual()[1]
                self.siguiente_token()
                if self.es_token('DELIMITADOR', '('):
                    self.siguiente_token()
                    parametros = self.parametros()
                    if self.es_token('DELIMITADOR', ')'):
                        self.siguiente_token()
                        if self.es_token('DELIMITADOR', ':'):
                            self.siguiente_token()
                            cuerpo = self.instrucciones()
                            funcion = {
                                'tipo': 'funcion',
                                'nombre': nombre,
                                'parametros': parametros,
                                'cuerpo': cuerpo
                            }
                            self.ast.append(funcion)
                        else:
                            raise SintacticoError("Se esperaba ':' después del ')'.")
                    else:
                        raise SintacticoError("Se esperaba ')' después de los parámetros.")
                else:
                    raise SintacticoError("Se esperaba '(' después del nombre de la función.")
            else:
                raise SintacticoError("Se esperaba el nombre de la función después de 'ritual'.")
        else:
            raise SintacticoError("Se esperaba 'ritual'.")
    def analizar(self):
        while self.obtener_token_actual() is not None:
            if self.es_token('DESCONOCIDO'):
                self.siguiente_token()
                continue
            try:
                self.declaracion_funcion()
            except SintacticoError as e:
                print("Error sintáctico:", e)
                return None
        print("El código es sintácticamente correcto.")
        return self.ast